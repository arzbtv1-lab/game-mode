package com.gamemode.app

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** รันคำสั่ง shell ด้วยสิทธิ์ ADB ผ่าน Shizuku (ไม่ต้อง root) */
object Sh {
    fun alive(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = try {
        alive() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun run(cmd: String): String {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            p.waitFor()
            (out + err).trim()
        } catch (e: Throwable) {
            "ERR: " + (e.cause?.message ?: e.message)
        }
    }

    /** วัด FPS จริงของเกมจาก SurfaceFlinger (เกมต้องอยู่หน้าจอ) คืน null ถ้าอ่านไม่ได้ */
    fun gameFps(pkg: String): Int? {
        val cmd = "L=\$(dumpsys SurfaceFlinger --list | grep \"$pkg\" | grep -i surfaceview | head -n1); " +
            "[ -z \"\$L\" ] && L=\$(dumpsys SurfaceFlinger --list | grep \"$pkg\" | head -n1); " +
            "[ -n \"\$L\" ] && dumpsys SurfaceFlinger --latency \"\$L\""
        val raw = run(cmd)
        if (raw.isEmpty() || raw.startsWith("ERR")) return null
        val times = ArrayList<Long>()
        raw.lines().drop(1).forEach { line ->
            val t = line.trim().split(Regex("\\s+"))
            if (t.size >= 3) {
                val v = t[1].toLongOrNull()
                if (v != null && v > 0L && v != Long.MAX_VALUE) times.add(v)
            }
        }
        if (times.size < 10) return null
        val span = times.last() - times.first()
        if (span <= 0L) return null
        return Math.round((times.size - 1) * 1_000_000_000.0 / span).toInt()
    }
}
