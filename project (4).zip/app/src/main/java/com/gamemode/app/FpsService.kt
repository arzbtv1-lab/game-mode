package com.gamemode.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder

/** วัด FPS ของเกมทุกวินาที แล้วแสดงในแจ้งเตือน (ไม่มี overlay) */
class FpsService : Service() {

    companion object {
        @Volatile var lastFps: Int = -1
        @Volatile var running: Boolean = false
        private const val CH = "fps"
    }

    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val pkg = intent?.getStringExtra("pkg")
        if (pkg.isNullOrEmpty()) { stopSelf(); return START_NOT_STICKY }

        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "FPS", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, build("กำลังวัด FPS..."))

        worker?.interrupt()
        running = true
        lastFps = -1
        worker = Thread {
            while (running && !Thread.currentThread().isInterrupted) {
                val f = Sh.gameFps(pkg)
                lastFps = f ?: -1
                nm.notify(1, build(if (f != null) "$f FPS" else "รอเกมเปิดอยู่หน้าจอ..."))
                try { Thread.sleep(1000) } catch (e: InterruptedException) { break }
            }
        }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun build(text: String): Notification =
        Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Game Mode")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .build()

    override fun onDestroy() {
        running = false
        lastFps = -1
        worker?.interrupt()
        super.onDestroy()
    }
}
