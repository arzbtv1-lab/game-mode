package com.gamemode.app

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** รันคำสั่ง shell ด้วยสิทธิ์ ADB ผ่าน Shizuku (ไม่ต้อง root) */
object Sh {
    fun alive(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = try {
        alive() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun run(cmd: String): String {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            p.waitFor()
            (out + err).trim()
        } catch (e: Throwable) {
            "ERR: " + (e.cause?.message ?: e.message)
        }
    }

    @Volatile var lastDebug: String = ""

    /** วัด FPS จริงของเกมจาก SurfaceFlinger (เกมต้องอยู่หน้าจอ) คืน null ถ้าอ่านไม่ได้ */
    fun gameFps(pkg: String): Int? {
        val list = run("dumpsys SurfaceFlinger --list | grep \"$pkg\"")
        val layers = list.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("ERR") }
        if (layers.isEmpty()) {
            lastDebug = "ไม่พบ layer ของ $pkg ใน SurfaceFlinger" + (if (list.startsWith("ERR")) " ($list)" else "")
            return null
        }
        val layer = layers.firstOrNull { it.contains("SurfaceView", true) && !it.contains("Background", true) }
            ?: layers.first()
        val raw = run("dumpsys SurfaceFlinger --latency \"$layer\"")
        val times = ArrayList<Long>()
        raw.lines().drop(1).forEach { line ->
            val t = line.trim().split(Regex("\\s+"))
            if (t.size >= 3) {
                val v = t[1].toLongOrNull()
                if (v != null && v > 0L && v != Long.MAX_VALUE) times.add(v)
            }
        }
        lastDebug = "layer=$layer rows=${times.size}"
        if (times.size < 10) return null
        val span = times.last() - times.first()
        if (span <= 0L) return null
        return Math.round((times.size - 1) * 1_000_000_000.0 / span).toInt()
    }
}
