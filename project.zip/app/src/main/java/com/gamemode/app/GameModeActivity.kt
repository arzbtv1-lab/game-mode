package com.gamemode.app

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import java.io.File
import rikka.shizuku.Shizuku

class GameModeActivity : Activity() {

    private enum class Mode(val label: String, val icon: String, val desc: String, val color: Int) {
        SAVE("ประหยัดแบต", "🔋", "ใช้งานปกติ ประหยัดแบตเตอรี่", 0xFF34D399.toInt()),
        BALANCE("สมดุล", "⚖️", "เคลียร์แอปพื้นหลัง + ห้ามรบกวน", 0xFF60A5FA.toInt()),
        MONSTER("MONSTER", "🔥", "เต็มกำลัง ล็อกประสิทธิภาพ จอรีเฟรชสูงสุด", 0xFFFFB020.toInt())
    }

    private val cBg = Color.parseColor("#0B0C10")
    private val cCard = Color.parseColor("#15171E")
    private val cCard2 = Color.parseColor("#1D2029")
    private val cLine = Color.parseColor("#262A36")
    private val cSub = Color.parseColor("#9AA0AE")
    private val cAccent = Color.parseColor("#FFB020")
    private val ui = Handler(Looper.getMainLooper())

    private var mode = Mode.BALANCE
    private var selectedPkg = ""

    private lateinit var tvTemp: TextView
    private lateinit var tvBatt: TextView
    private lateinit var tvRam: TextView
    private lateinit var tvCpu: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvShizuku: TextView
    private lateinit var tvFps: TextView
    private lateinit var tvFpsNote: TextView
    private lateinit var tvLog: TextView
    private lateinit var tvModeDesc: TextView
    private lateinit var tvGameName: TextView
    private lateinit var tvGamePkg: TextView
    private lateinit var ivGame: ImageView
    private val modeBox = mutableMapOf<Mode, LinearLayout>()
    private val modeLabel = mutableMapOf<Mode, TextView>()

    private val tick = object : Runnable {
        override fun run() { refresh(); ui.postDelayed(this, 1500) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        val prefs = getSharedPreferences("gm", MODE_PRIVATE)
        mode = Mode.values()[prefs.getInt("mode", 1)]
        selectedPkg = prefs.getString("pkg", "com.roblox.client") ?: ""

        val root = ScrollView(this).apply { setBackgroundColor(cBg) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(22), dp(16), dp(28))
        }
        root.addView(col)

        // ---------- หัวเรื่อง ----------
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(text("GAME MODE", 24f, Color.WHITE, true).apply { letterSpacing = 0.08f })
        titles.addView(text("ปรับเครื่องให้พร้อมเล่น", 12f, cSub))
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        tvShizuku = text("", 11f, Color.WHITE, true).apply {
            setPadding(dp(12), dp(7), dp(12), dp(7))
            setOnClickListener { askShizuku() }
        }
        head.addView(tvShizuku)
        col.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        // ---------- ค่าเครื่อง ----------
        val srow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tvCpu = statTile(srow, "CPU")
        tvTemp = statTile(srow, "ความร้อน")
        tvBatt = statTile(srow, "แบตเตอรี่")
        tvRam = statTile(srow, "RAM ว่าง")
        col.addView(srow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        // ---------- FPS ----------
        val fpsCard = card()
        fpsCard.addView(text("FPS ของเกม", 12f, cSub, true))
        tvFps = text("--", 52f, cAccent, true).apply { gravity = Gravity.CENTER }
        fpsCard.addView(tvFps, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
        tvFpsNote = text("กดเริ่มเล่นเพื่อวัด FPS จริงจากระบบ", 11f, cSub).apply { gravity = Gravity.CENTER }
        fpsCard.addView(tvFpsNote)
        fpsCard.addView(
            pill("หยุดวัด FPS", cCard2, Color.WHITE, 13f) { stopService(Intent(this, FpsService::class.java)) },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
        )
        col.addView(fpsCard)

        // ---------- โหมด ----------
        val modes = card()
        modes.addView(text("โหมดประสิทธิภาพ", 14f, Color.WHITE, true))
        val mrow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Mode.values().forEach { m ->
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(0, dp(12), 0, dp(12))
                setOnClickListener { select(m) }
            }
            box.addView(text(m.icon, 22f, Color.WHITE).apply { gravity = Gravity.CENTER })
            val lb = text(m.label, 12f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
            box.addView(lb, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) })
            mrow.addView(box, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
            modeBox[m] = box; modeLabel[m] = lb
        }
        modes.addView(mrow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        tvModeDesc = text("", 12f, cSub).apply { gravity = Gravity.CENTER }
        modes.addView(tvModeDesc, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        tvStatus = text("", 11f, cSub).apply { gravity = Gravity.CENTER }
        modes.addView(tvStatus)
        tvLog = text("", 10f, Color.parseColor("#6B7280")).apply { gravity = Gravity.CENTER }
        modes.addView(tvLog)
        col.addView(modes)

        // ---------- เกม ----------
        val game = card()
        game.addView(text("เกมที่จะเล่น", 14f, Color.WHITE, true))
        val grow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = round(cCard2, 16, cLine, 1)
            setOnClickListener { pickGame() }
        }
        ivGame = ImageView(this)
        grow.addView(ivGame, LinearLayout.LayoutParams(dp(46), dp(46)))
        val gtxt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tvGameName = text("เลือกเกม", 15f, Color.WHITE, true)
        tvGamePkg = text("", 10f, cSub)
        gtxt.addView(tvGameName); gtxt.addView(tvGamePkg)
        grow.addView(gtxt, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
        grow.addView(text("เปลี่ยน ›", 12f, cAccent, true))
        game.addView(grow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val go = text("▶  เริ่มเล่น", 17f, Color.parseColor("#1A1200"), true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(15), 0, dp(15))
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#FFC93C"), Color.parseColor("#FF8A1F"))
            ).apply { cornerRadius = dp(28).toFloat() }
            setOnClickListener {
                if (selectedPkg.isEmpty()) {
                    Toast.makeText(this@GameModeActivity, "เลือกเกมก่อน", Toast.LENGTH_SHORT).show()
                } else {
                    applyMode()
                    if (startFps()) launchGame()
                }
            }
        }
        game.addView(go, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        col.addView(game)

        setContentView(root)
        paintModes()
        showGame()
    }

    override fun onResume() { super.onResume(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    // ---------- เลือกเกม ----------
    private val gamePrefixes = listOf(
        "com.roblox", "com.dts.freefire", "com.mobile.legends", "com.tencent", "com.activision",
        "com.supercell", "com.miHoYo", "com.HoYoverse", "com.garena", "com.pubg", "com.proximabeta",
        "com.netease", "com.innersloth", "com.mojang", "com.epicgames", "com.king", "com.ea."
    )

    private fun isGame(a: ApplicationInfo): Boolean =
        (Build.VERSION.SDK_INT >= 26 && a.category == ApplicationInfo.CATEGORY_GAME) ||
            gamePrefixes.any { a.packageName.startsWith(it) }

    private fun pickGame() {
        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { it.packageName != packageName && pm.getLaunchIntentForPackage(it.packageName) != null }
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .sortedWith(compareBy({ !isGame(it) }, { pm.getApplicationLabel(it).toString().lowercase() }))

        if (apps.isEmpty()) {
            Toast.makeText(this, "ไม่พบแอปที่ติดตั้ง", Toast.LENGTH_SHORT).show()
            return
        }

        val adapter = object : ArrayAdapter<ApplicationInfo>(this, 0, apps) {
            override fun getView(pos: Int, convert: View?, parent: ViewGroup): View {
                val a = getItem(pos)!!
                val row = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(16), dp(10), dp(16), dp(10))
                }
                val icon = ImageView(context).apply { setImageDrawable(pm.getApplicationIcon(a)) }
                row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))
                val name = TextView(context).apply {
                    text = pm.getApplicationLabel(a).toString()
                    setTextColor(Color.WHITE); textSize = 15f
                }
                row.addView(name, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
                if (isGame(a)) {
                    row.addView(TextView(context).apply {
                        text = "เกม"; textSize = 10f; setTextColor(Color.parseColor("#1A1200"))
                        typeface = Typeface.DEFAULT_BOLD
                        setPadding(dp(8), dp(3), dp(8), dp(3))
                        background = round(cAccent, 10)
                    })
                }
                return row
            }
        }

        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("เลือกเกม")
            .setAdapter(adapter) { _, which ->
                selectedPkg = apps[which].packageName
                getSharedPreferences("gm", MODE_PRIVATE).edit().putString("pkg", selectedPkg).apply()
                showGame()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun showGame() {
        try {
            val info = packageManager.getApplicationInfo(selectedPkg, 0)
            tvGameName.text = packageManager.getApplicationLabel(info).toString()
            tvGamePkg.text = selectedPkg
            ivGame.setImageDrawable(packageManager.getApplicationIcon(info))
        } catch (e: Exception) {
            tvGameName.text = "แตะเพื่อเลือกเกม"
            tvGamePkg.text = if (selectedPkg.isEmpty()) "" else "ไม่พบแอป $selectedPkg"
            ivGame.setImageDrawable(null)
        }
    }

    // ---------- โหมด ----------
    private fun select(m: Mode) {
        mode = m
        getSharedPreferences("gm", MODE_PRIVATE).edit().putInt("mode", m.ordinal).apply()
        paintModes()
        applyMode()
    }

    private fun gamePkg() = selectedPkg

    private fun askShizuku() {
        if (!Sh.alive()) {
            Toast.makeText(this, "เปิดแอป Shizuku แล้วกด Start ก่อน", Toast.LENGTH_LONG).show()
            packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
        } else if (!Sh.granted()) {
            try { Shizuku.requestPermission(100) } catch (e: Throwable) {}
        }
    }

    private fun startFps(): Boolean {
        if (Sh.granted()) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "อนุญาต \"แสดงทับแอปอื่น\" ให้ Game Mode เพื่อให้ FPS ลอยที่มุมจอ แล้วกดเริ่มใหม่", Toast.LENGTH_LONG).show()
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName"))
                )
                return false
            }
            startForegroundService(Intent(this, FpsService::class.java).putExtra("pkg", gamePkg()))
        } else {
            Toast.makeText(this, "ต้องให้สิทธิ์ Shizuku ก่อนถึงจะวัด FPS ได้", Toast.LENGTH_LONG).show()
        }
        return true
    }

    private fun applyMode() {
        val done = mutableListOf<String>()
        val pkg = gamePkg()

        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(
                if (mode == Mode.SAVE) NotificationManager.INTERRUPTION_FILTER_ALL
                else NotificationManager.INTERRUPTION_FILTER_PRIORITY
            )
            if (mode != Mode.SAVE) done += "ห้ามรบกวน"
        } else if (mode != Mode.SAVE) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }

        val best = windowManager.defaultDisplay.supportedModes.maxByOrNull { it.refreshRate }
        val lp = window.attributes
        lp.preferredDisplayModeId = if (mode == Mode.MONSTER && best != null) best.modeId else 0
        window.attributes = lp

        val keepOn = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        if (mode == Mode.SAVE) window.clearFlags(keepOn) else window.addFlags(keepOn)

        if (Sh.granted()) {
            tvStatus.text = "กำลังใช้โหมด ${mode.label}..."
            Thread {
                val log = StringBuilder()
                if (mode != Mode.SAVE) {
                    val safe = if (pkg.isEmpty()) "none.none" else pkg
                    val r = Sh.run(
                        "for p in \$(pm list packages -3 | cut -d: -f2); do " +
                            "case \"\$p\" in moe.shizuku*|com.gamemode.app|$safe) ;; " +
                            "*) am force-stop \$p;; esac; done"
                    )
                    log.append("ปิดแอปพื้นหลัง: ").append(if (r.isEmpty()) "ok" else r).append("\n")
                }
                val fixed = if (mode == Mode.MONSTER) "true" else "false"
                val r2 = Sh.run("cmd power set-fixed-performance-mode-enabled $fixed")
                log.append("fixed performance=$fixed: ").append(if (r2.isEmpty()) "ok" else r2).append("\n")
                val sc = if (mode == Mode.MONSTER) "0.5" else "1.0"
                Sh.run(
                    "settings put global window_animation_scale $sc; " +
                        "settings put global transition_animation_scale $sc; " +
                        "settings put global animator_duration_scale $sc"
                )
                log.append("อนิเมชันระบบ x$sc: ok")
                runOnUiThread {
                    tvStatus.text = "ใช้โหมด ${mode.label} แล้ว (ADB)"
                    tvLog.text = log.toString()
                }
            }.start()
        } else {
            if (mode != Mode.SAVE) {
                val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
                packageManager.getInstalledApplications(0).forEach {
                    if (it.packageName != packageName && it.packageName != pkg &&
                        (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0
                    ) am.killBackgroundProcesses(it.packageName)
                }
                done += "เคลียร์แอปพื้นหลัง"
            }
            tvStatus.text = (if (done.isEmpty()) "ใช้โหมด ${mode.label}" else "ทำแล้ว: " + done.joinToString(" • ")) +
                "\n(โหมดพื้นฐาน — เชื่อม Shizuku เพื่อให้ทำงานเต็ม)"
            tvLog.text = ""
        }
    }

    private fun launchGame() {
        val i = packageManager.getLaunchIntentForPackage(selectedPkg)
        if (i != null) startActivity(i)
        else Toast.makeText(this, "ไม่พบเกม $selectedPkg", Toast.LENGTH_SHORT).show()
    }

    // ---------- อ่านค่าจริง ----------
    private fun refresh() {
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val lvl = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        tvTemp.text = "%.1f°C".format(temp)
        tvTemp.setTextColor(
            when {
                temp < 38f -> Color.parseColor("#4ADE80")
                temp < 42f -> Color.parseColor("#FFC107")
                else -> Color.parseColor("#F87171")
            }
        )
        tvBatt.text = "$lvl%"
        tvRam.text = "${mi.availMem / 1048576} MB"
        tvCpu.text = cpuMaxMhz()?.let { "$it MHz" } ?: "—"

        val (label, color) = when {
            Sh.granted() -> "● Shizuku พร้อม" to Color.parseColor("#34D399")
            Sh.alive() -> "● แตะเพื่อขอสิทธิ์" to Color.parseColor("#FFC107")
            else -> "● ยังไม่เปิด Shizuku" to Color.parseColor("#F87171")
        }
        tvShizuku.text = label
        tvShizuku.setTextColor(color)
        tvShizuku.background = round(Color.argb(40, Color.red(color), Color.green(color), Color.blue(color)), 20, color, 1)

        val f = FpsService.lastFps
        if (FpsService.running && f <= 0) tvLog.text = "debug: " + Sh.lastDebug
        when {
            !FpsService.running -> {
                tvFps.text = "--"; tvFps.setTextColor(cSub)
                tvFpsNote.text = "กดเริ่มเล่นเพื่อวัด FPS จริงจากระบบ"
            }
            f > 0 -> {
                tvFps.text = "$f"
                tvFps.setTextColor(
                    when {
                        f >= 50 -> Color.parseColor("#4ADE80")
                        f >= 30 -> Color.parseColor("#FFC107")
                        else -> Color.parseColor("#F87171")
                    }
                )
                tvFpsNote.text = "กำลังวัด • ดูตัวเลขที่มุมจอระหว่างเล่นได้"
            }
            else -> {
                tvFps.text = "--"; tvFps.setTextColor(cSub)
                tvFpsNote.text = "รอเกมเปิดอยู่หน้าจอ..."
            }
        }
    }

    private fun cpuMaxMhz(): Int? {
        var max = 0
        for (c in 0 until Runtime.getRuntime().availableProcessors()) {
            try {
                val khz = File("/sys/devices/system/cpu/cpu$c/cpufreq/scaling_cur_freq").readText().trim().toInt()
                if (khz > max) max = khz
            } catch (e: Exception) {}
        }
        return if (max > 0) max / 1000 else null
    }

    // ---------- UI helper ----------
    private fun paintModes() {
        Mode.values().forEach { m ->
            val on = m == mode
            val c = m.color
            modeBox[m]?.background =
                if (on) round(Color.argb(46, Color.red(c), Color.green(c), Color.blue(c)), 16, c, 2)
                else round(cCard2, 16, cLine, 1)
            modeLabel[m]?.setTextColor(if (on) c else Color.WHITE)
        }
        tvModeDesc.text = mode.desc
    }

    private fun pill(label: String, bg: Int, fg: Int, size: Float, onClick: () -> Unit) =
        text(label, size, fg, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(11), 0, dp(11))
            background = round(bg, 22, cLine, 1)
            setOnClickListener { onClick() }
        }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = round(cCard, 20, cLine, 1)
        setPadding(dp(16), dp(14), dp(16), dp(16))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
    }

    private fun statTile(parent: LinearLayout, label: String): TextView {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(4), dp(12), dp(4), dp(12))
            background = round(cCard, 16, cLine, 1)
        }
        val v = text("—", 14f, Color.WHITE, true).apply { gravity = Gravity.CENTER; maxLines = 1 }
        box.addView(v)
        box.addView(text(label, 10f, cSub).apply { gravity = Gravity.CENTER })
        parent.addView(box, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        return v
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun round(c: Int, r: Int, stroke: Int = 0, strokeDp: Int = 0) = GradientDrawable().apply {
        setColor(c); cornerRadius = dp(r).toFloat()
        if (strokeDp > 0) setStroke(dp(strokeDp), stroke)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
