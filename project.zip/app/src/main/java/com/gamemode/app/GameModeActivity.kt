package com.gamemode.app

import android.app.Activity
import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import java.io.File
import rikka.shizuku.Shizuku

class GameModeActivity : Activity() {

    private enum class Mode(val label: String) { SAVE("ประหยัดแบต"), BALANCE("สมดุล"), MONSTER("MONSTER") }

    private val yellow = Color.parseColor("#FFC107")
    private val panel = Color.parseColor("#1E1E22")
    private val chip = Color.parseColor("#2C2C31")
    private val ui = Handler(Looper.getMainLooper())

    private var mode = Mode.BALANCE
    private lateinit var tvTemp: TextView
    private lateinit var tvBatt: TextView
    private lateinit var tvRam: TextView
    private lateinit var tvCpu: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvShizuku: TextView
    private lateinit var tvFps: TextView
    private lateinit var tvLog: TextView
    private lateinit var etPkg: EditText
    private val modeButtons = mutableMapOf<Mode, TextView>()

    private val tick = object : Runnable {
        override fun run() { refresh(); ui.postDelayed(this, 1500) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK
        val prefs = getSharedPreferences("gm", MODE_PRIVATE)
        mode = Mode.values()[prefs.getInt("mode", 1)]

        val root = ScrollView(this).apply { setBackgroundColor(Color.BLACK) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        root.addView(col)

        // ---- ค่าจริงจากเครื่อง ----
        val stats = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tvCpu = stat(row, "CPU"); tvTemp = stat(row, "อุณหภูมิ")
        tvBatt = stat(row, "แบตเตอรี่"); tvRam = stat(row, "RAM ว่าง")
        stats.addView(row)
        col.addView(stats)

        // ---- Shizuku ----
        val sh = card()
        sh.addView(title("สิทธิ์ ADB (Shizuku)"))
        tvShizuku = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 13f }
        sh.addView(tvShizuku)
        sh.addView(button("ขอสิทธิ์ Shizuku", chip, Color.WHITE) {
            if (!Sh.alive()) {
                Toast.makeText(this, "เปิดแอป Shizuku แล้วกด Start ก่อน", Toast.LENGTH_LONG).show()
                packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
            } else if (!Sh.granted()) {
                try { Shizuku.requestPermission(100) } catch (e: Throwable) {}
            }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        col.addView(sh)

        // ---- โหมด ----
        val modes = card()
        modes.addView(title("โหมดประสิทธิภาพ"))
        val mrow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Mode.values().forEach { m ->
            val t = TextView(this).apply {
                text = m.label; gravity = Gravity.CENTER; textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(12), 0, dp(12))
                setOnClickListener { select(m) }
            }
            mrow.addView(t, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
            modeButtons[m] = t
        }
        modes.addView(mrow)
        tvStatus = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 12f; setPadding(0, dp(10), 0, 0) }
        modes.addView(tvStatus)
        tvLog = TextView(this).apply { setTextColor(Color.GRAY); textSize = 11f; setPadding(0, dp(6), 0, 0) }
        modes.addView(tvLog)
        col.addView(modes)

        // ---- FPS ----
        val fps = card()
        fps.addView(title("FPS ของเกม (ค่าจริงจากระบบ)"))
        tvFps = TextView(this).apply {
            setTextColor(yellow); textSize = 34f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; text = "—"
        }
        fps.addView(tvFps)
        fps.addView(TextView(this).apply {
            setTextColor(Color.GRAY); textSize = 11f; gravity = Gravity.CENTER
            text = "ดูระหว่างเล่นได้ที่แจ้งเตือน (ลากแถบด้านบนลง)"
        })
        fps.addView(button("หยุดวัด FPS", chip, Color.WHITE) {
            stopService(Intent(this, FpsService::class.java))
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        col.addView(fps)

        // ---- เกม ----
        val game = card()
        game.addView(title("เกม"))
        etPkg = EditText(this).apply {
            setText(prefs.getString("pkg", "com.roblox.client"))
            setTextColor(Color.WHITE); textSize = 14f
            hint = "package ของเกม"; setHintTextColor(Color.GRAY)
        }
        game.addView(etPkg)
        game.addView(button("ใช้โหมด + เปิดเกม + วัด FPS", yellow, Color.BLACK) {
            prefs.edit().putString("pkg", etPkg.text.toString().trim()).apply()
            applyMode()
            if (startFps()) launchGame()
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        col.addView(game)

        setContentView(root)
        paintModes()
    }

    override fun onResume() { super.onResume(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    private fun select(m: Mode) {
        mode = m
        getSharedPreferences("gm", MODE_PRIVATE).edit().putInt("mode", m.ordinal).apply()
        paintModes()
        applyMode()
    }

    private fun gamePkg() = etPkg.text.toString().trim()

    private fun startFps(): Boolean {
        if (Sh.granted()) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "อนุญาต \"แสดงทับแอปอื่น\" ให้ Game Mode เพื่อให้ FPS ลอยที่มุมจอ แล้วกดเริ่มใหม่", Toast.LENGTH_LONG).show()
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName"))
                )
                return false
            }
            startForegroundService(Intent(this, FpsService::class.java).putExtra("pkg", gamePkg()))
        } else {
            Toast.makeText(this, "ต้องให้สิทธิ์ Shizuku ก่อนถึงจะวัด FPS ได้", Toast.LENGTH_LONG).show()
        }
        return true
    }

    private fun applyMode() {
        val done = mutableListOf<String>()
        val pkg = gamePkg()

        // ห้ามรบกวน
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(
                if (mode == Mode.SAVE) NotificationManager.INTERRUPTION_FILTER_ALL
                else NotificationManager.INTERRUPTION_FILTER_PRIORITY
            )
            if (mode != Mode.SAVE) done += "ห้ามรบกวน"
        } else if (mode != Mode.SAVE) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }

        // รีเฟรชเรตสูงสุด
        val best = windowManager.defaultDisplay.supportedModes.maxByOrNull { it.refreshRate }
        val lp = window.attributes
        lp.preferredDisplayModeId = if (mode == Mode.MONSTER && best != null) best.modeId else 0
        window.attributes = lp

        // ไม่ให้จอดับ
        val keepOn = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        if (mode == Mode.SAVE) window.clearFlags(keepOn) else window.addFlags(keepOn)

        if (Sh.granted()) {
            // โหมดเต็ม: ใช้สิทธิ์ ADB
            tvStatus.text = "กำลังใช้โหมด ${mode.label}..."
            Thread {
                val log = StringBuilder()
                if (mode != Mode.SAVE) {
                    val safe = if (pkg.isEmpty()) "none.none" else pkg
                    val r = Sh.run(
                        "for p in \$(pm list packages -3 | cut -d: -f2); do " +
                            "case \"\$p\" in moe.shizuku*|com.gamemode.app|$safe) ;; " +
                            "*) am force-stop \$p;; esac; done"
                    )
                    log.append("ปิดแอปพื้นหลัง: ").append(if (r.isEmpty()) "ok" else r).append("\n")
                }
                val fixed = if (mode == Mode.MONSTER) "true" else "false"
                val r2 = Sh.run("cmd power set-fixed-performance-mode-enabled $fixed")
                log.append("fixed performance=$fixed: ").append(if (r2.isEmpty()) "ok" else r2).append("\n")
                val sc = if (mode == Mode.MONSTER) "0.5" else "1.0"
                Sh.run(
                    "settings put global window_animation_scale $sc; " +
                        "settings put global transition_animation_scale $sc; " +
                        "settings put global animator_duration_scale $sc"
                )
                log.append("อนิเมชันระบบ x$sc: ok")
                runOnUiThread {
                    tvStatus.text = "ใช้โหมด ${mode.label} แล้ว (ADB)"
                    tvLog.text = log.toString()
                }
            }.start()
        } else {
            // โหมดพื้นฐาน (ยังไม่ได้ต่อ Shizuku)
            if (mode != Mode.SAVE) {
                val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
                packageManager.getInstalledApplications(0).forEach {
                    if (it.packageName != packageName && it.packageName != pkg &&
                        (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0
                    ) am.killBackgroundProcesses(it.packageName)
                }
                done += "เคลียร์แอปพื้นหลัง"
            }
            tvStatus.text = (if (done.isEmpty()) "ใช้โหมด ${mode.label}" else "ทำแล้ว: " + done.joinToString(" • ")) +
                "\n(โหมดพื้นฐาน — เชื่อม Shizuku เพื่อให้ทำงานเต็ม)"
            tvLog.text = ""
        }
    }

    private fun launchGame() {
        val pkg = gamePkg()
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) startActivity(i)
        else Toast.makeText(this, "ไม่พบเกม $pkg", Toast.LENGTH_SHORT).show()
    }

    private fun refresh() {
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val lvl = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        tvTemp.text = "%.1f°C".format(temp)
        tvBatt.text = "$lvl%"
        tvRam.text = "${mi.availMem / 1048576} MB"
        tvCpu.text = cpuMaxMhz()?.let { "$it MHz" } ?: "—"

        tvShizuku.text = when {
            Sh.granted() -> "✅ เชื่อมต่อแล้ว พร้อมใช้งานเต็มรูปแบบ"
            Sh.alive() -> "⚠️ Shizuku ทำงานอยู่ แต่ยังไม่ได้ให้สิทธิ์ — กดปุ่มด้านล่าง"
            else -> "❌ ยังไม่ได้เปิด Shizuku (ใช้ได้แค่โหมดพื้นฐาน)"
        }
        tvFps.text = when {
            !FpsService.running -> "—"
            FpsService.lastFps > 0 -> "${FpsService.lastFps} FPS"
            else -> "รอเกม..."
        }
    }

    private fun cpuMaxMhz(): Int? {
        var max = 0
        for (c in 0 until Runtime.getRuntime().availableProcessors()) {
            try {
                val khz = File("/sys/devices/system/cpu/cpu$c/cpufreq/scaling_cur_freq").readText().trim().toInt()
                if (khz > max) max = khz
            } catch (e: Exception) {}
        }
        return if (max > 0) max / 1000 else null
    }

    private fun paintModes() = modeButtons.forEach { (m, t) ->
        val on = m == mode
        t.background = round(if (on) yellow else chip, 14)
        t.setTextColor(if (on) Color.BLACK else Color.WHITE)
    }

    private fun button(text: String, bg: Int, fg: Int, onClick: () -> Unit) = TextView(this).apply {
        this.text = text; gravity = Gravity.CENTER
        setTextColor(fg); typeface = Typeface.DEFAULT_BOLD; textSize = 15f
        setPadding(0, dp(13), 0, dp(13)); background = round(bg, 28)
        setOnClickListener { onClick() }
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = round(panel, 18)
        setPadding(dp(14), dp(14), dp(14), dp(14))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
    }

    private fun title(s: String) = TextView(this).apply {
        text = s; setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 0, 0, dp(10))
    }

    private fun stat(parent: LinearLayout, label: String): TextView {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val v = TextView(this).apply {
            setTextColor(yellow); textSize = 17f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; text = "—"
        }
        val l = TextView(this).apply { setTextColor(Color.GRAY); textSize = 11f; gravity = Gravity.CENTER; text = label }
        box.addView(v); box.addView(l)
        parent.addView(box, LinearLayout.LayoutParams(0, -2, 1f))
        return v
    }

    private fun round(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
