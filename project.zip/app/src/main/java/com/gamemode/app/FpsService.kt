package com.gamemode.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** วัด FPS ของเกมทุกวินาที แสดงเป็นแถบสวยๆ มุมบนซ้าย + ในแจ้งเตือน */
class FpsService : Service() {

    companion object {
        @Volatile var lastFps: Int = -1
        @Volatile var running: Boolean = false
        private const val CH = "fps"
    }

    private var worker: Thread? = null
    private var overlay: LinearLayout? = null
    private var numView: TextView? = null
    private var tempView: TextView? = null
    private var dotView: View? = null
    private val main = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val pkg = intent?.getStringExtra("pkg")
        if (pkg.isNullOrEmpty()) { stopSelf(); return START_NOT_STICKY }

        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "FPS", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, build("กำลังวัด FPS..."))

        showOverlay()

        worker?.interrupt()
        running = true
        lastFps = -1
        worker = Thread {
            while (running && !Thread.currentThread().isInterrupted) {
                val f = Sh.gameFps(pkg)
                lastFps = f ?: -1
                val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
                nm.notify(1, build(if (f != null) "$f FPS  •  %.0f°C".format(temp) else "รอเกมเปิดอยู่หน้าจอ..."))
                main.post { updateOverlay(f, temp) }
                try { Thread.sleep(1000) } catch (e: InterruptedException) { break }
            }
        }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun fpsColor(f: Int?): Int = when {
        f == null -> Color.parseColor("#9CA3AF")
        f >= 50 -> Color.parseColor("#4ADE80")
        f >= 30 -> Color.parseColor("#FFC107")
        else -> Color.parseColor("#F87171")
    }

    private fun updateOverlay(f: Int?, temp: Float) {
        val c = fpsColor(f)
        numView?.text = f?.toString() ?: "--"
        numView?.setTextColor(c)
        tempView?.text = "%.0f°C".format(temp)
        (dotView?.background as? GradientDrawable)?.setColor(c)
    }

    private fun showOverlay() {
        if (overlay != null) return
        if (!Settings.canDrawOverlays(this)) return
        try {
            val dot = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#9CA3AF")) }
            }
            val num = TextView(this).apply {
                text = "--"; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.parseColor("#9CA3AF"))
            }
            val label = TextView(this).apply {
                text = "FPS"; textSize = 10f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.parseColor("#9CA3AF"))
            }
            val divider = View(this).apply { setBackgroundColor(Color.parseColor("#33FFFFFF")) }
            val temp = TextView(this).apply {
                text = "--°C"; textSize = 12f; setTextColor(Color.parseColor("#D1D5DB"))
            }
            val close = TextView(this).apply {
                text = "✕"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE); gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#33FFFFFF")) }
                setOnClickListener { stopSelf() }
            }

            val box = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(5), dp(6), dp(5))
                background = GradientDrawable().apply {
                    cornerRadius = dp(20).toFloat()
                    setColor(Color.parseColor("#D9101216"))
                    setStroke(dp(1), Color.parseColor("#33FFFFFF"))
                }
                addView(dot, LinearLayout.LayoutParams(dp(8), dp(8)).apply { rightMargin = dp(8) })
                addView(num)
                addView(label, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(3) })
                addView(divider, LinearLayout.LayoutParams(dp(1), dp(14)).apply { leftMargin = dp(8); rightMargin = dp(8) })
                addView(temp)
                addView(close, LinearLayout.LayoutParams(dp(24), dp(24)).apply { leftMargin = dp(10) })
            }

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(8) }

            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(box, lp)
            overlay = box; numView = num; tempView = temp; dotView = dot
        } catch (e: Throwable) {
            overlay = null; numView = null; tempView = null; dotView = null
        }
    }

    private fun build(text: String): Notification =
        Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Game Mode")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .build()

    override fun onDestroy() {
        running = false
        lastFps = -1
        worker?.interrupt()
        try {
            overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        } catch (e: Throwable) {}
        overlay = null; numView = null; tempView = null; dotView = null
        super.onDestroy()
    }
}
