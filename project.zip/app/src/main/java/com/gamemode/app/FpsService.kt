package com.gamemode.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** วัด FPS ของเกมทุกวินาที แสดงที่มุมบนซ้ายของจอ + ในแจ้งเตือน */
class FpsService : Service() {

    companion object {
        @Volatile var lastFps: Int = -1
        @Volatile var running: Boolean = false
        private const val CH = "fps"
    }

    private var worker: Thread? = null
    private var overlay: LinearLayout? = null
    private var fpsText: TextView? = null
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val pkg = intent?.getStringExtra("pkg")
        if (pkg.isNullOrEmpty()) { stopSelf(); return START_NOT_STICKY }

        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "FPS", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, build("กำลังวัด FPS..."))

        showOverlay()

        worker?.interrupt()
        running = true
        lastFps = -1
        worker = Thread {
            while (running && !Thread.currentThread().isInterrupted) {
                val f = Sh.gameFps(pkg)
                lastFps = f ?: -1
                val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
                val line = if (f != null) "FPS $f  •  %.1f°C".format(temp) else "FPS —  •  %.1f°C".format(temp)
                nm.notify(1, build(if (f != null) "$f FPS" else "รอเกมเปิดอยู่หน้าจอ..."))
                main.post { fpsText?.text = line }
                try { Thread.sleep(1000) } catch (e: InterruptedException) { break }
            }
        }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun showOverlay() {
        if (overlay != null) return
        if (!Settings.canDrawOverlays(this)) return
        try {
            val label = TextView(this).apply {
                text = "FPS —"
                setTextColor(Color.parseColor("#FFC107"))
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                setPadding(16, 6, 12, 6)
            }
            val close = TextView(this).apply {
                text = "✕"
                setTextColor(Color.WHITE)
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(22, 6, 22, 6)
                setBackgroundColor(Color.parseColor("#55FFFFFF"))
                setOnClickListener { stopSelf() }
            }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(Color.parseColor("#99000000"))
                addView(label)
                addView(close)
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = 8; y = 8 }
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(box, lp)
            overlay = box
            fpsText = label
        } catch (e: Throwable) {
            overlay = null
            fpsText = null
        }
    }

    private fun build(text: String): Notification =
        Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Game Mode")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .build()

    override fun onDestroy() {
        running = false
        lastFps = -1
        worker?.interrupt()
        try {
            overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        } catch (e: Throwable) {}
        overlay = null
        fpsText = null
        super.onDestroy()
    }
}
